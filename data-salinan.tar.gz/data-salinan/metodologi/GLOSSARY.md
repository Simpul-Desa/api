# Glosarium SIMPUL DESA

Sumber sah untuk penamaan di produk ini. Kalau sebuah istilah ada di sini, pakai
persis bentuk ini — di UI, di nama komponen, di nama kolom basis data, dan di
dokumen. Kalau sebuah konsep belum ada di sini, tambahkan dulu sebelum menulis
kode yang menamainya.

Berkas ini memuat **definisi, bukan angka**. Cacah hasil dan parameter model
tidak ditulis di sini karena keduanya bergerak; sumbernya keluaran `data/`, dan
tiap bagian menunjuk ke berkas yang berwenang. Batasnya: angka yang tanpanya
sebuah definisi rusak boleh tinggal (jumlah zona, skala persentil, ambang
median); angka yang merupakan hasil hitungan atau setelan model tidak.

Berlaku per 6 September 2026.

## Nama produk

**SIMPUL DESA** — Sistem Intelijen Potensi dan Kesiapan Ekonomi Desa.

Ditulis kapital seluruhnya bila berdiri sendiri sebagai nama sistem. Dalam
kalimat berjalan boleh "Simpul Desa". Jangan disingkat menjadi "SD" — bentrok
dengan singkatan sekolah dasar.

## Lima fitur utama

**Peta Peran** — menempatkan tiap desa ke satu dari empat zona penanganan,
sehingga jelas siapa yang harus bergerak lebih dulu: pemerintah, mitra swasta,
atau perlindungan sosial.

**Kartu Ekonomi Desa** — profil ekonomi lengkap tiap desa tanpa satu pun
formulir. Seluruh desa/kelurahan di provinsi percontohan terdata otomatis, nol
kuesioner, nol beban bagi perangkat desa. Cakupan wilayahnya ada di
`data/README.md` bagian Cakupan.

**Jalur Ekonomi** — menyambung sekumpulan desa ke satu aset bersama di lokasi
optimal, agar skalanya cukup besar untuk hidup. Punya empat varian — Komoditas,
Gudang Kopdes, Cold Storage, dan Wisata — lihat bagian Varian Jalur Ekonomi.

**Desa Kembar** — mencari desa yang profilnya paling mirip dengan desa yang
sudah terbukti berhasil, sehingga jalur suksesnya bisa ditiru dengan modal
kemiripan yang terukur.

**Citra Potensi Desa** — menemukan sentra komoditas dari pembacaan citra satelit
dan peta, sehingga potensi desa terbaca tanpa desa perlu melaporkannya.

## Fitur tambahan

Tiga fitur di luar lima fitur utama, ditetapkan di [PRD.md](./PRD.md).
Sumber sah aksesnya (siapa boleh apa) adalah matriks peran di PRD; di sini
hanya definisi.

**Asisten Desa** — antarmuka percakapan berbasis LLM yang menjawab hanya
dari data SIMPUL DESA — keluaran model, kartu, berita, termasuk metodologi
skor — dan menolak topik di luar itu. Bukan sumber angka baru: semua angka
diambil dari data yang sudah ada.

**Berita Desa** — kumpulan berita per desa hasil panen otomatis, tersimpan
per `iddesa`, tampil sebagai bagian Kartu Ekonomi Desa.

**Laporan Desa** — dokumen PDF per desa yang memuat sekurangnya Peta Peran
dan Kartu Ekonomi Desa. Hanya peran tertentu yang boleh membuatnya — lihat
matriks di PRD.

## Empat zona penanganan

Keluaran dari **Peta Peran**: matriks dua sumbu dengan empat kuadran.

- Sumbu tegak: **Skor Potensi**, rendah di bawah, tinggi di atas.
- Sumbu datar: **Skor Kesiapan**, rendah di kiri, tinggi di kanan.

Nomor kuadran berjalan searah jarum jam dari kiri-atas.

```
Potensi
tinggi │  Kuadran 1        Kuadran 2
       │  Zona Pemerintah  Zona Mitra
       │
rendah │  Kuadran 4        Kuadran 3
       │  Zona Bantuan     Zona Poros
       └──────────────────────────────
          rendah            tinggi
                  Kesiapan
```

| Kuadran | Zona | Potensi | Kesiapan | Penanganan |
|---|---|---|---|---|
| 1 | **Zona Pemerintah** | tinggi | rendah | Prioritas Dana Desa, infrastruktur, dan pendampingan |
| 2 | **Zona Mitra** | tinggi | tinggi | Langsung dipertemukan dengan pembeli tetap atau investor |
| 3 | **Zona Poros** | rendah | tinggi | Cocok jadi pusat pengolahan bagi desa sekitarnya |
| 4 | **Zona Bantuan** | rendah | rendah | Jangan dipaksa berusaha; bantuan tepat sasaran dan akses ke poros terdekat |

Yang ditampilkan ke pengguna adalah nama zonanya, bukan nomor kuadrannya. Nomor
dipakai untuk rujukan internal dan penamaan di kode. Nama zona selalu ditulis
lengkap dengan kata "Zona".

**Belum Terpetakan** — keadaan kelima di luar empat zona: wilayah yang bukti
kesiapannya terukur tidak lebih dari separuh bobot tidak diberi zona, karena
menyebutnya "kesiapan rendah" berarti menyatakan desa itu tidak siap padahal
yang terjadi adalah datanya kosong. Kartu wilayah Belum Terpetakan tetap
menampilkan seluruh komponen yang seharusnya ada — komponen yang kosong
ditulis dengan tanda "—" dan keterangan sumbernya, bukan disembunyikan.

**Keyakinan rendah** — bendera pada desa yang skornya berjarak kurang dari
2 poin dari salah satu ambang zona. Penempatan zonanya rapuh terhadap
perubahan kecil pada data atau bobot, dan kartu wajib menampilkannya. Bendera
ini melekat pada penempatan zona, bukan pada skornya.

Padanan istilah di catatan produk terhadap kedua sumbu: "produksi terbatas"
berarti Skor Potensi rendah, "kelembagaan kuat" berarti Skor Kesiapan tinggi.

## Skor dan ambang Peta Peran

Mesinnya di `data/fitur/peta-peran/`; angka ambang yang berlaku ada di keluarannya.

- **Skor Potensi** — persentil 0–100 dalam kabupaten, nilai tertinggi antar
  delapan sub-skor tematik. Enam sub-skor subsektor diambil dari skor
  tervalidasi Citra Potensi Desa; tema Perikanan Tangkap dihitung dari garis
  pantai dan pangsa rumah tangga perikanan (hanya kabupaten berpantai); tema
  Simpul Logistik dihitung dari akses dan amenitas niaga.
  Wisata tidak ikut menyusun Skor Potensi — wisata tampil sebagai lapisan
  fakta registri sampai ditemukan data potensi wisata yang teruji. Alasan dan
  ambang kelulusannya di ADR-0004 (`docs/adr/`); angka mutunya di
  `data/machine-learning/citra-potensi-desa/wisata/BRIEF-WISATA.md`.
- **Skor Kesiapan** — rerata berbobot empat komponen (Indeks Desa Membangun,
  kelembagaan ekonomi, amenitas dan keuangan, konektivitas), pembagi hanya
  bobot yang terukur; skala 0–100 dalam kabupaten.
- **Ambang zona** — median kabupaten pada masing-masing sumbu, dihitung hanya
  dari wilayah yang kesiapannya terukur. Skor ditampilkan sebagai desil dan
  peringkat dalam kabupaten, bukan angka desimal; selisih kecil tidak boleh
  ditafsirkan sebagai perbedaan nyata.

### Delapan tema sub-skor

Nama tema ditulis persis begini di mana pun ia tampil — kartu, peta, legenda,
maupun kalimat Rekomendasi Aksi:

**Tanaman Pangan** · **Hortikultura** · **Perkebunan** · **Peternakan** ·
**Perikanan Budidaya** · **Perikanan Tangkap** · **Kehutanan** ·
**Simpul Logistik**.

Enam nama pertama adalah subsektor. "Perikanan Budidaya" tidak boleh disebut
"perikanan" saja: sejak tema perikanan dipecah dua, "perikanan" sendirian
rancu dengan Perikanan Tangkap. Nama pendek di kode (`tp`, `horti`, `kebun`,
`ternak`, `ikan`, `hutan`, `tangkap`, `simpul`) adalah identifier, bukan
bentuk yang terlihat pengguna.

**Potensi Dominan** — tema tempat maksimum persentil Skor Potensi tercapai,
yaitu alasan sebuah desa mendapat skornya. Bila tema pemenangnya berasal dari
sel Citra Potensi Desa yang tervalidasi, Potensi Dominan menyebut komoditasnya
dengan pemisah tanda pisah: `Perkebunan — Kelapa`. Perikanan Tangkap dan
Simpul Logistik tidak pernah menyebut komoditas karena keduanya bukan skor
per komoditas. Desa tanpa satu pun sub-skor terukur tidak punya Potensi
Dominan; kolomnya kosong, bukan diisi tema tebakan.

**Sumber Potensi Dominan** — empat nilai, dan wajib tampil berdampingan
dengan Potensi Dominan karena mutunya berbeda-beda:

- **citra** — dari sel Citra Potensi Desa yang lolos uji tertahan, jadi angkanya
  punya sertifikat mutu (average precision).
- **heuristik-tervalidasi** — rumus heuristik yang sudah diuji dengan kunci
  jawaban dari luar dan menang. Perikanan Tangkap masuk sini: kuncinya nama
  desa dari lampiran keputusan menteri tentang kampung nelayan.
- **heuristik-belum-teruji** — rumus heuristik yang belum punya kunci
  pendukung. Simpul Logistik masuk sini. Mutunya paling lemah di antara
  keempatnya dan itu **harus terbaca, bukan disamarkan**; jangan menyajikannya
  setara dengan citra.
- **fallback-heuristik** — dari pangsa rumah tangga subsektor, dipakai ketika
  provinsi itu tidak punya sel tervalidasi untuk subsektor tersebut.

**Sentralitas** — rerata waktu tempuh dalam menit dari sebuah desa ke seluruh
desa lain di kabupatennya, dihitung dari matriks waktu tempuh jalan. Makin
kecil menitnya makin sentral desa itu; sebagai komponen Skor Kesiapan arahnya
dibalik supaya "tinggi" selalu berarti "lebih siap". Sentralitas mengukur
posisi terhadap desa-desa lain, bukan jarak ke pusat kota — keduanya variabel
berbeda dan tidak boleh dipertukarkan.

## Kartu Ekonomi Desa: kode kosong, Rekomendasi Aksi, Fakta Program

Mesinnya di `data/fitur/kartu-ekonomi-desa/`.

Nilai yang kosong di kartu selalu membawa kode alasan — kosong-karena-tidak-
dinilai berbeda dari kosong-karena-belum-terpetakan:

- **TIDAK-DINILAI** — instrumennya memang tidak menilai wilayah ini
  (kelurahan tidak dinilai IDM). Struktural, bukan cacat data.
- **TIDAK-TERPETAKAN** — sumber sukarela benar-benar tidak menghitung wilayah
  itu, sehingga nilainya tidak ada sama sekali. **Nol bukan termasuk di sini.**
  Sejak aturan nol diubah, nol pada hitungan titik minat berarti *tidak ada*,
  bukan *belum dipetakan* — angka nol ditampilkan apa adanya dan ikut menyusun
  skor, karena "tidak punya warung" memang informasi tentang kesiapan.
- **TIDAK-BERLAKU** — temanya tidak relevan untuk wilayah ini (Perikanan
  Tangkap di kabupaten tanpa pantai).
- **TIDAK-ADA-DATA** — data seharusnya ada tetapi tidak diperoleh
  (desa tanpa geometri).

**Rekomendasi Aksi** — satu-dua kalimat tindakan per desa yang dirakit mesin
dari aturan tetap (zona × Potensi Dominan × Fakta Program), bukan dari model
bahasa. Setiap kalimatnya dapat ditelusuri ke aturannya.

**Fakta Program** — lapisan berisi keikutsertaan desa pada registri program
publik. Fakta Program tidak pernah masuk ke Skor Potensi maupun Skor
Kesiapan: registri adalah penempatan kebijakan, bukan bukti potensi, dan
memakainya sebagai skor akan menghadiahi desa hanya karena sudah pernah
dipilih. Isinya:

- **Jadesta** — registri desa wisata Kemenpar: kategori verifikasi beserta
  jumlah atraksi, paket, dan homestay.
- **Registri desa wisata Sisparnas** — daftar desa wisata Kemenpar di luar
  Jadesta, ter-join ke `iddesa` lewat koordinat.
- **Daya tarik wisata Sisparnas** — cacah titik daya tarik wisata yang jatuh
  di dalam wilayah desa.
- **Kampung Perikanan Budidaya** — desa penerima program budidaya KKP,
  beserta komoditasnya. Fakta program, bukan skor: sebagai kunci uji
  Perikanan Budidaya ia terbukti lemah, dan itu memang konsekuensi wajar dari
  program pengembangan.
- **Kampung Nelayan** — desa dalam lampiran Kepmen-KP (KALAJU, Kalamo, KNMP),
  beserta nama program dan tahunnya. Nama "Kampung Nelayan" dipakai untuk
  fakta program ini saja; kesiapan pesisir sebuah desa sebagai skor selalu
  disebut Perikanan Tangkap.
- **Cold storage eksisting** — unit gudang beku yang sudah berdiri di desa
  itu, beserta jenis, kapasitas, dan statusnya.

Isi lapisan ini bergerak saat registri bertambah; daftar dan cacah yang
berlaku ada di `data/fitur/kartu-ekonomi-desa/README.md`.

**Belum tersentuh** — bendera pada desa yang tidak muncul di satu pun registri
program yang dipantau. Bukan cacat data melainkan pesan utama: sebagian besar
desa belum tersentuh registri mana pun. Pada desa Zona Pemerintah, bendera
inilah temuan terpentingnya. Cacah yang berlaku ada di
`data/fitur/kartu-ekonomi-desa/README.md`.

**Kemiripan Desa Kembar** — ditetapkan: persen kemiripan = (1 − jarak ÷
persentil-95 jarak antar desa sekabupaten) × 100 pada ruang fitur model
kNN v3, dipotong 0–100. Relatif dalam kabupaten.

## Varian Jalur Ekonomi

Mesinnya di `data/machine-learning/jalur-ekonomi/`. Parameter yang berlaku —
waktu tempuh maksimum, volume minimum, rem biaya buka, dan bobot minimum
kawasan — ada di `MODEL.md` folder itu dan di bagian `parameter` tiap
`varian-*/hasil_*.json`. Berkas ini hanya menamai dan membedakan variannya.

Satu mesin penempatan yang sama menjawab dua pertanyaan berbeda. Setiap varian
menghasilkan daftar Desa Poros dan Desa Sejalur miliknya sendiri. Yang berlaku
untuk keempatnya: sebuah jalur berisi 2 sampai 25 desa, dan ambang volumenya
digelembungkan seperlima supaya jalur tetap sah bila volumenya turun.
**Waktu tempuh maksimum** (T maksimum) adalah kendala keras: desa yang
lebih jauh dari itu tidak bisa menjadi anggota, bukan dikenai penalti.

**Komoditas** — rantai usaha satu komoditas: desa-desa dengan komoditas
sejenis disambungkan ke satu titik pengolahan bersama. Volume dihitung dari
satu komoditas itu saja. Parameternya berbeda per subsektor; angkanya di
`MODEL.md`. Varian ini tanpa biaya buka — jumlah jalur dibatasi volume
minimum saja.

**Gudang Kopdes** — jaringan penyimpanan lintas komoditas: desa-desa
disambungkan ke satu gudang bersama yang dikelola koperasi desa (Kopdes),
tanpa memandang jenis komoditasnya. Volume dihitung dari gabungan beberapa
subsektor — seluruh rumah tangga tani kabupaten, tanpa perikanan dan
peternakan yang butuh rantai dingin atau rumah potong sendiri. Parameter
terpilih adalah **opsi B, biaya buka endogen**: gudang baru hanya dibuka bila
hemat tempuhnya melampaui biayanya, sehingga jumlah gudang ditentukan model.

**Cold Storage** — jaringan gudang beku perikanan: desa-desa penghasil
komoditas yang wajib segera didinginkan (bandeng, udang, hasil laut)
disambungkan ke satu cold storage bersama. Volume dihitung hanya dari
komoditas kelas rantai dingin; komoditas yang lazim dijual hidup (lele, nila)
dan yang dijemur (rumput laut) tidak dihitung. Varian ini hanya berjalan di
kabupaten pesisir yang volumenya mencukupi. Kandidat terpilih adalah **K2,
median (p,q) berkondisi** (*conditional (p,q)-median*): gudang beku yang
sudah berdiri ikut menyerap desa-desa di sekitarnya, dan hanya kekurangannya
yang dijawab dengan unit baru. K2 sengaja **tidak memakai radius eksklusi** di
sekitar gudang beku eksisting: kandidat yang memakai radius eksklusi (K1) buta
terhadap daya serap unit lama dan kalah jauh. "Cold storage" adalah
pengecualian sadar atas aturan istilah Inggris — istilah serapan teknis yang
di dunia perikanan lebih dikenal daripada padanan Indonesianya.

Dua hal berbeda yang bisa muncul bersamaan pada satu desa dan tidak boleh disamakan: **cold storage eksisting** adalah unit yang berdiri di desa itu sendiri, sedangkan **keterlayanan cold storage** adalah desa yang berada dalam jangkauan sebuah unit — unitnya bisa di desa lain. Keduanya fakta, bukan peran: Desa Poros varian ini hanya diberikan pada unit BARU yang diusulkan model, supaya gudang beku yang kebetulan sudah berdiri tidak terbaca sebagai temuan model.

**Wisata** — kawasan paket desa wisata: desa-desa wisata terdaftar (registri
Jadesta dan registri desa wisata Sisparnas) yang berdekatan waktu tempuh
disambungkan menjadi satu kawasan yang layak dipaketkan bersama, dengan satu
desa basis kawasan sebagai Desa Poros (gerbang, pusat layanan, konsentrasi
tempat menginap). Berbeda dari tiga varian lain, bobotnya bukan volume rumah
tangga melainkan kematangan dan daya tampung desa wisata: kandidat terpilih
**W6** memberi bobot kategori Jadesta digandakan lalu menambahkan jumlah
atraksi, paket, dan homestay yang dikompresi log1p, supaya hitungan isian
mandiri desa tidak menyandera bobotnya. Biaya buka dibedakan: desa yang sudah
bermodal akomodasi dikenai biaya lebih rendah daripada desa tanpa modal —
mahalnya membangun penginapan dari nol dihitung, tetapi tidak dijadikan
kendala keras yang mematikan kabupaten miskin modal. Varian ini berdiri di
atas fakta registri, bukan prediksi.

Setiap varian, apa pun temanya, selalu menghasilkan dua peran yang sama:
Desa Poros dan Desa Sejalur. Varian tanpa keduanya bukan varian Jalur Ekonomi.

Nama lama "Jalur Komoditas" tidak dipakai lagi: variannya disebut Komoditas,
keseluruhan fiturnya Jalur Ekonomi. Bila kata "Komoditas" sendirian bisa rancu
dengan makna umumnya, tulis "varian Komoditas".

## Peran desa di dalam Jalur Ekonomi

**Desa Poros** — desa yang menjadi lokasi aset bersama dalam satu jalur:
titik pengolahan pada varian Komoditas, gudang pada Gudang Kopdes, gudang
beku pada Cold Storage, dan desa basis kawasan pada Wisata.

**Desa Sejalur** — desa anggota yang dilayani oleh sebuah Desa Poros.

Peran melekat per varian: satu desa bisa menjadi Desa Poros di Gudang Kopdes
sekaligus Desa Sejalur di sebuah jalur varian Komoditas. Satu desa juga bisa
menyandang peran ini sekaligus masuk ke sebuah zona penanganan. Peran dan zona
adalah dua atribut berbeda, bukan satu daftar pilihan.

## Peran pengguna

Empat peran tersimpan plus satu keadaan tanpa login. Matriks akses lengkap
milik [PRD.md](./PRD.md); di sini nama dan definisinya. Jangan disamakan
dengan peran desa (Desa Poros, Desa Sejalur) — itu atribut desa, ini akun
manusia.

- **anonim** — keadaan sebelum login, bukan peran tersimpan. Hanya melihat
  Kartu Ekonomi Desa, tanpa Berita Desa.
- **tamu** — peran bawaan setiap registrasi mandiri: melihat semua fitur dan
  Berita Desa, tanpa Asisten Desa dan tanpa Laporan Desa.
- **pemerintah** — pengguna instansi pemerintah, dinaikkan oleh admin: semua
  fitur, Asisten Desa, dan Laporan Desa.
- **swasta** — pengguna mitra swasta, dinaikkan oleh admin: seperti
  pemerintah, tanpa Laporan Desa.
- **admin** — pengelola sistem: semua akses plus halaman `/admin`.

Registrasi mandiri selalu menghasilkan tamu; kenaikan peran hanya dilakukan
admin.

## Padanan tetap

Satu konsep, satu nama. Kolom kanan adalah bentuk yang dipakai; kolom kiri
adalah bentuk yang **tidak** dipakai walaupun artinya sama.

| Jangan | Pakai |
|---|---|
| village | desa |
| twin village, desa serupa | Desa Kembar |
| hub village | Desa Poros |
| readiness, readiness score | Skor Kesiapan |
| potential, potential score | Skor Potensi |
| Zona Swasta | Zona Mitra |
| Zona Perlindungan | Zona Bantuan |
| kuadran I, II, III, IV | Kuadran 1, 2, 3, 4 |
| commodity chain, rantai komoditas, Jalur Komoditas (varian) | Komoditas |
| gudang bersama, warehouse, gudang desa | Gudang Kopdes |
| Rantai Dingin, gudang beku (sebagai nama varian), jalur perikanan | Cold Storage |
| Jalur Wisata, rute wisata, kawasan wisata (sebagai nama varian), tourism route | Wisata |
| Jalur Komoditas (keseluruhan fitur) | Jalur Ekonomi |
| role map, matriks aktor | Peta Peran |
| kesiapan tidak terukur, tanpa kuadran, unclassified | Belum Terpetakan |
| low confidence, rapuh, borderline | keyakinan rendah |
| village card, kartu potensi | Kartu Ekonomi Desa |
| satellite engine, mesin geospasial | Citra Potensi Desa |
| tema dominan, dominant theme, sektor unggulan | Potensi Dominan |
| perikanan (sebagai nama tema) | Perikanan Budidaya |
| pangan, tanaman pangan (huruf kecil sebagai nama tema) | Tanaman Pangan |
| posisi logistik, hub logistik | Simpul Logistik |
| centrality, closeness, aksesibilitas rerata | sentralitas |
| lapisan program, program layer, status program | Fakta Program |
| radius layanan, radius maksimum | waktu tempuh maksimum |
| member village, spoke village | Desa Sejalur |
| assignment | penugasan |
| monitoring aktif | pemantauan aktif |
| AI chat, chatbot, asisten AI | Asisten Desa |
| report, ekspor PDF (sebagai nama fitur) | Laporan Desa |
| news, kabar desa | Berita Desa |
| guest | tamu |

Istilah Inggris hanya boleh muncul di identifier kode (nama variabel, tabel,
rute). Yang terlihat pengguna selalu bahasa Indonesia.

## Konvensi penulisan

- Bahasa antarmuka: Indonesia. Tidak ada campuran dalam satu kalimat.
- Desimal memakai koma: `72,4` — bukan `72.4`.
- Ribuan memakai titik: `1.248` — bukan `1,248`.
- Persen menempel angkanya: `68%`.
- Satuan dipisah spasi: `42 kPa`, `3,2 km`.
- Tanggal ringkas: `24 Agu 25`. Bulan disingkat tiga huruf, tanpa titik.
- Wilayah disingkat: `Kec.` untuk kecamatan, `Kab.` untuk kabupaten, `Prov.`
  untuk provinsi. Urutan menyempit ke melebar: `Desa • Kec. • Kab. • Provinsi`.
- Nama desa ditulis tanpa kata "Desa" bila sudah jelas dari konteks kolomnya,
  dan dengan kata "Desa" bila berdiri sendiri sebagai judul.

## Belum ditetapkan

Ditandai supaya tidak ada yang mengarang isinya.

- **Definisi kelas rantai dingin.** Daftar komoditas perikanan yang wajib
  segera didinginkan (dan yang tidak) sudah dipakai varian Cold Storage
  sebagai sumber tunggal, tetapi belum divalidasi ahli perikanan. Nama
  kelasnya sah; keanggotaan komoditasnya masih bisa berubah.

Parameter keempat varian Jalur Ekonomi tidak lagi berada di sini — semuanya
sudah diketok, dan angkanya tercatat di `data/machine-learning/jalur-ekonomi/MODEL.md`
serta di bagian `parameter` tiap `varian-*/hasil_*.json`, bukan di glosarium ini.

## Berkas terkait

- [README.md](./README.md) — peta folder dan kontrak antar folder.
- [PRD.md](./PRD.md) — scope produk, peran pengguna dan matriks aksesnya,
  batas MVP.
- [CLAUDE.md](./CLAUDE.md) — aturan kerja lintas sesi.
- [app/DESIGN.md](./app/DESIGN.md) — sistem visual. Komponen dinamai memakai
  istilah di berkas ini.
- [data/README.md](./data/README.md) — cakupan wilayah, keluaran, dan seluruh
  angka yang tidak ditulis di sini.
- [docs/adr/](./docs/adr/) — keputusan tahan lama dan jalur yang sudah ditutup.
