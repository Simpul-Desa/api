# MODEL.md — spesifikasi teknis Jalur Ekonomi

Kartu model lengkap: data, formulasi, parameter, kalibrasi, hasil, batasan.
Naskah metode awal (pra-MILP) = lampiran README. README =
ringkasan; berkas ini = **rujukan teknis keadaan sekarang** (3 Sep 2026).

---

## 1. Mesin inti — MILP capacitated facility location (`mesin_milp.py`)

Satu model per (kabupaten × tema). Menggabungkan pembentukan gerombolan
(Desa Sejalur) dan penetapan lokasi aset (Desa Poros) dalam satu solve eksak.

### 1.1 Data masukan

| Sumber | Isi | Peran |
|---|---|---|
| `../../panen/gabung/desa_ml.csv` | 17.467 desa/kelurahan, 5 provinsi (18/33/52/63/73), 97 kab; ST2023 + geospasial | identitas desa, volume (per varian), atribut skor |
| `matriks/tt_<idkab>.npz` | matriks OSRM NxN per kabupaten (menit, arah asli; `bangun_matriks.py`, server publik router.project-osrm.org, profil driving) | jarak; dipakai simetris: `tt_sym = nanmean(tt, ttᵀ)`; NaN = tak tersambung; desa tanpa koordinat dikeluarkan saat build |
| `../../panen/komoditas/<prov>.json` | kamus 60 komoditas/provinsi | label + subsektor (varian Komoditas) |

### 1.2 Formulasi

Himpunan: anggota tema i, j ∈ A (desa lolos saring `min_mutlak`); pasangan
layak (i,j) hanya bila `tt_sym[i,j]` terhingga dan ≤ T_maks (sparse — kendala
radius KERAS ada di pembentukan variabel, bukan penalti). Fasilitas tetap
f ∈ F (opsional, varian Cold Storage K2/K3).

Variabel biner:
- `y_j` — desa j dibuka sebagai Poros/aset baru
- `x_ij` — desa i dilayani Poros baru j
- `xf_if` — desa i diserap fasilitas eksisting f (bila F ≠ ∅)

Kendala:
1. `Σ_j x_ij + Σ_f xf_if ≤ 1` — desa maksimal satu jalur (baru ATAU eksisting)
2. `x_ij ≤ y_j` ; `x_jj = y_j` (Poros melayani dirinya)
3. `Σ_i v_i·x_ij ≥ V_ROBUST·y_j`, **V_ROBUST = ceil(V_min/0,8)** — ambang
   digelembungkan sehingga jalur tetap sah saat volume −20% (skenario P10)
4. `MIN_ANGGOTA·y_j ≤ Σ_i x_ij ≤ MAKS_ANGGOTA·y_j` (2 dan 25)
5. `Σ_i v_i·xf_if ≤ kapasitas_ruta_f` — fasilitas eksisting berkapasitas;
   tanpa V_min/MIN/MAKS/biaya (sudah berdiri)
6. `y_j = 0` untuk j ∉ kandidat_poros (opsional; eksklusi K1)

Tujuan (maksimasi; semua koefisien integer, **SKALA = 100**):

```
  Σ_ij v_i·S·x_ij                                  cakupan (dominan)
− Σ_ij round(v_i·tt_ij·S·0,5/T_maks)·x_ij          biaya tempuh berbobot volume
+ Σ_if [v_i·S − round(v_i·tt_if·S·0,5/T_maks)]·xf  cakupan+tempuh ke eksisting
+ Σ_j  [round(infra_j·v̄·S·0,01) − biaya_buka]·y_j  bonus kesiapan − rem buka
```

Bobot tempuh maksimal 0,5·v_i (di tt = T_maks) → mencakup desa SELALU
menguntungkan bila layak; `biaya_buka = round(β·V_ROBUST·S)` membuat jumlah
fasilitas endogen (buka baru hanya bila hemat tempuhnya melebihi biaya).

### 1.3 Solver

OR-Tools **CP-SAT**; `num_search_workers = 5`, `random_seed = 11` (paralel
tetap bisa beda tipis), batas waktu `WAKTU_MAKS` per solve: 30 dtk (Komoditas)
· 120 dtk (Gudang, model sekabupaten) · 60 dtk (Cold Storage). Gap
optimalitas = (BestObjectiveBound − ObjectiveValue)/ObjectiveValue — sertifikat
mutu; solusi FEASIBLE bergap besar biasanya tetap bermutu (bound yang longgar).

### 1.4 Jaminan struktural keluaran

Setiap jalur: volume ≥ V_min bahkan pada P10 (−20%); semua anggota ≤ T_maks
dari Poros (by construction); ≤ 25 dan ≥ 2 desa; tanpa duplikat desa.
Diverifikasi `uji_jalur.py` (kendala keras → exit 1).

---

## 2. Varian Komoditas (runner: `mesin_milp.py main()`)

- **Volume**: `kom_prov_<subsektor>_<nn>` — jumlah ruta usaha satu komoditas
  (ST2023, top-10 per subsektor per provinsi; kamus `komoditas/<prov>.json`).
- **Parameter per subsektor** (T_maks menit / min_mutlak / V_min ruta),
  turunan ambang greedy lama, ditata per komoditas tunggal:
  tp 30/100/1000 · horti 30/60/600 · kebun 40/40/400 · ternak 45/40/400 ·
  ikan 45/25/250 · hutan 60/20/200. `biaya_buka = 0` (jumlah jalur dibatasi
  V_ROBUST saja). Skor lokasi: `skor_infra` (§5).
- **Hasil 97 kab (5 Sep 2026, solver reprodusibel)**: 1.712 kombinasi,
  22.049 jalur, cakupan volume rerata 85,6% (Kalsel 68,3 — struktural
  rawa/sungai), P90 23,6 mnt, **1.145 OPTIMAL** (dari 778; gap rerata
  0,3296 -> 0,0055),
  kendala bersih. Keluaran `varian-komoditas/hasil_komoditas.json`.
- **Pembanding yang dikalahkan** (§6): max-p 35,0% volume-kualitas vs MILP
  87,0% (3 kab pilot, menang 75/seri 15/kalah 0).

## 3. Varian Gudang Kopdes (runner: `gudang_kopdes.py`)

- **Volume**: `n_ruta_tani` (ruta tani total — gudang serbaguna; perikanan &
  peternakan di luar: butuh cold chain/RPH). Satu solve per kabupaten.
- **Parameter produksi (opsi B, menang uji 3 opsi × 6 kab)**: T_maks 40 ·
  min_mutlak 100 · V_min 2.500 · **β = 0,30** (biaya buka 93.750 unit tujuan);
  WAKTU 120 dtk. Opsi kalah: A (V_min 5.000, β 0 — mati di kepulauan:
  Selayar 1 gudang/53 yatim) dan C (5.000 + β 0,15 — rem ganda).
- **Acuan riset**: gudang KDMP ±600 m² (Inpres 17/2025); gudang SRG 600 m² ≈
  1.200 ton (Bappebti); median ruta per kecamatan 4.523.
- **Hasil 97 kab (5 Sep 2026)**: 860 gudang (dari 895 — lebih sedikit untuk
  cakupan setara), cakupan 88,7%, P90 20,7 mnt, gap rerata 0,0330 -> 0,0024,
  kabupaten OPTIMAL 33 -> 71, kendala bersih;
  8 kota TAK_LAYAK (wajar). Keluaran `varian-gudang-kopdes/hasil_gudang.json`.
- Status parameter: **DIKETOK 3 Sep 2026** (GLOSSARY §Varian Jalur Ekonomi).

## 4. Varian Cold Storage (runner: `cold_storage.py`)

- **Volume**: `ruta_dingin` dari
  `../../panen/eksternal/cold-storage/ruta_dingin_desa.csv` — ruta komoditas
  perikanan kelas **rantai dingin** (bandeng/udang/laut) menurut
  `klasifikasi_ikan.json` (sumber tunggal definisi; **belum divalidasi ahli
  perikanan**). Kelas jual-hidup (lele, nila) & jemur (rumput laut) tak ikut.
- **Fasilitas eksisting**: `cold_storage_titik_desa.csv` (312 titik KKP
  ter-map ke desa; pakai `idkab_poligon`, bukan klaim `id_kabupat`) — saring
  OPERASIONAL & ≥ 100 ton → fasilitas tetap-terbuka, kapasitas ruta =
  **ton × 16** (kalibrasi unit 30 ton + ABF ≈ throughput 300 ton/thn ≈ 500
  ruta pada produktivitas ±3 ton/ruta/thn, 10–20% lewat gudang beku — KASAR,
  layak uji kepekaan).
- **Model produksi (K2, diketok 3 Sep 2026)**: conditional **(p,q)-median**
  (Minieka 1980; Berman & Drezner 2008) — q fasilitas lama menyerap, p baru
  endogen. T_maks 45 (batas fisik ikan segar) · min_mutlak 25 · V_min 500
  (~unit KKP 30 ton; benchmark KNMP 2025: 10 ton/unit awal) · β 0,30 (biaya
  18.750) · WAKTU 60 dtk. Kandidat kalah: K1 eksklusi radius 30 mnt (buta
  penyerapan — Pati: 33% vs K2 100%) dan K3 T_maks 60 + skor perikanan
  (menang cakupan hanya dengan melanggar batas fisik; P90 48–55 mnt).
- **Hasil 45 kab pesisir**: 20 layak → 32 CS baru + 17 eksisting terpakai
  (9.064 ruta terserap oleh 18 unit lama), cakupan 83,2%, P90 26,6 mnt,
  20/20 OPTIMAL, kendala
  bersih. Kotabaru/Tanah Bumbu/Luwu rendah struktural (kepulauan → moda lain).
  Keluaran `varian-cold-storage/hasil_cold_storage.json`.

## 4b. Varian Wisata (runner: `jalur_wisata.py`)

- **Volume**: kolom **`bobot_v2`** (BAKU di CSV, `regen_wisata_bobot.py`) dari
  `../../panen/eksternal/wisata/wisata_bobot_desa.csv` — sejak 4 Sep 2026
  basis registri Sisparnas **1.154 desa** (dari 436 Jadesta lama) = 2×
  bobot_kategori (RINTISAN 1…MANDIRI 6, verifikasi Kemenpar) + log1p(n_atraksi)
  + log1p(n_paket) + log1p(n_homestay). Kompresi log1p mencegah hitungan
  isian-mandiri menyandera (audit: n_atraksi 35% bobot v1; desa RINTISAN bisa
  78–84). Keanggotaan: semua desa registri (min_mutlak 1).
- **Model produksi (W6, diketok 3 Sep 2026)**: mesin MILP + **biaya buka
  berdiferensiasi** (dict per kandidat — perluasan `biaya_buka` mesin):
  basis bermodal (n_homestay ≥ 1 ∪ poi_penginapan OSM > 0 ∪ kategori
  MAJU/MANDIRI) β 0,3, tanpa modal β 1,0 (= harga membangun akomodasi).
  T_maks 45 · V_min 6 (robust 8) · WAKTU 30 dtk. Kandidat kalah: W1 bebas,
  W2/W4 kendala keras basis (runtuh di kab miskin modal — median kandidat
  2/kab), W3 radius 30 (runtuh di kab jarang), W5 (=W6 tanpa bobot v2).
  Uji 3 ronde × 15 kab: W6 menang/seri semua, satu-satunya yang membentuk
  kawasan di Pesisir Barat.
- **Skor lokasi**: `skor_wisata` = rerata persentil (n_homestay,
  bobot_kategori, −menit_ke_pusat_kota).
- **Hasil (basis registri Sisparnas 1.154 desa, 4 Sep 2026 malam) 95 kab**: 359 kawasan, cakupan kab-berkawasan 91,5%, P90 27,7 mnt, 85 OPTIMAL / 2 FEASIBLE / 8 TAK_LAYAK,
  basis bermodal 112/129 tanpa kendala keras; 5 kab nol kawasan (2 desa
  berjauhan — fakta spasial). Keluaran `varian-wisata/hasil_wisata.json`.
- **Kepekaan V_min (uji formal 4 Sep 2026, basis 1.154)**: butir "tinjau ulang
  V_min" ditutup dengan angka, bukan dengan penilaian. Runner diberi bendera
  `--v-min N` yang menulis ke sandbox `varian-wisata/uji-vmin/`, kini
  diarsipkan ke `../../arsip/jalur-ekonomi-uji-vmin/` (produksi tak
  tersentuh); W6 dijalankan penuh 97 kabupaten pada V_min 8, 10, dan 12 lalu
  dibandingkan dengan produksi V_min 6:

  | V_min | kawasan | kab berkawasan | cakupan bobot | desa yatim | bobot kawasan (median / min) | anggota (median) | P90 |
  |---|---|---|---|---|---|---|---|
  | **6 (produksi)** | **359** | **81** | **78,0%** | **106** | 13 / 8 | 2 | 27,7 |
  | 8 | 322 | 78 | 75,3% | 115 | 14 / 10 | 2 | 28,7 |
  | 10 | 255 | 74 | 70,6% | 135 | 17 / 13 | 3 | 29,3 |
  | 12 | 204 | 70 | 66,5% | 158 | 21 / 15 | 4 | 29,7 |

  Bacaan: V_ROBUST memang MENGIKAT (kawasan terkecil produksi persis 8,00 =
  ceil(6/0,8)), jadi angkanya bukan hiasan. Tetapi kurvanya **monoton dan
  tanpa titik patah** — tidak ada nilai yang secara empiris "benar". Yang
  dibeli dengan menaikkan V_min adalah kawasan yang lebih berisi (median
  bobot 13 → 21, anggota 2 → 4); yang dibayar adalah 155 kawasan, 11
  kabupaten yang jadi kosong sama sekali, 11,5 poin cakupan, dan 52 desa
  yatim tambahan. V_min 6 DIPERTAHANKAN: produk ini alat prioritisasi, bukan
  keputusan anggaran final, dan kabupaten miskin modal yang kehilangan
  seluruh kawasannya adalah kerugian yang lebih besar daripada kawasan kecil
  yang bisa dinilai sendiri oleh pembacanya — asalkan bobot dan jumlah
  anggota kawasan ikut ditampilkan.
- Batasan: bobot = fakta registri (desa belum terdaftar Sisparnas/Jadesta tak
  terlihat). Sebaran bobot per desa nyaris tak bergeser saat basis naik dari
  436 ke 1.154 (median 4,48 → 4,08; rerata 5,35 → 5,05) — yang berubah adalah
  kepadatan desa wisata per kabupaten (median 9 desa/kab), sehingga skala
  V_min lama tetap sebanding.

## 5. Skor kelayakan lokasi (`skor_infra`, `skor_perikanan`, `skor_wisata`)

- `skor_infra` (`mesin_maxp.py`): rerata persentil dalam-kabupaten dari
  (a) log1p(lumbung + penggilingan + koperasi_tani), (b) −menit_ke_pusat_kota.
  0–100. Bonus tujuan kecil (koef 0,01·v̄·S per poin) + pemecah seri.
- `skor_perikanan` (`cold_storage.py`, dipakai K3 saja): persentil
  (a) −jarak lurus km ke pelabuhan perikanan PIPP terdekat, (b) `tl_tambak`.
- `skor_wisata` (`jalur_wisata.py`): rerata persentil (n_homestay,
  bobot_kategori, −menit_ke_pusat_kota) — didefinisikan di §4b.

## 6. Pembanding riwayat (`mesin_maxp.py`) — bukan produksi

- **max-p-regions** (spopt `MaxPHeuristic`): atribut homogenitas
  [pangsa komoditas, elevasi] z-score; threshold V_min; 3 seed (11/22/33),
  terbaik = cakupan lalu biaya; `ITER_KONSTRUKSI 12`, `ITER_SA 3`, tenggat
  SIGALRM 120 dtk + jalan pintas komponen < 2·V_min (spopt bisa berputar tak
  henti). Pecah kapasitas k-median + tempel-sisa. Poros = 1-median berbobot
  volume, seri <5% → skor infra.
- **greedy lama** (port `build_koridor.py` dari pipeline prototipe lama ke matriks tt).
- Kelemahan terukur max-p: 232 anggota melampaui T_maks (rantai), rapuh P10
  (44,8%), ARI antar seed 0,52 — alasan MILP menang.

## 7. Metrik evaluasi (naskah §6)

1. % volume tema tercakup jalur sah; 2. jumlah jalur & desa tak tercakup;
3. median & P90 menit anggota→Poros; 4. % jalur sah di P10 (MILP: 100% by
construction); 5. stabilitas antar seed (ARI, khusus max-p); 6. gap
optimalitas (khusus MILP). Uji kendala otomatis: `uji_jalur.py` — sejak
4 Sep 2026 mencakup keempat varian (20.009 jalur komoditas, 896 gudang,
49 unit cold storage, 359 kawasan wisata: nol pelanggaran keras, nol
pelanggaran t_maks). Unit `cs_eksisting` sengaja dikecualikan dari v_min,
MIN_ANGGOTA, dan poros-jadi-anggota: fasilitas terpasang, bukan usulan.

## 8. Batasan diketahui (jangan dihapus dari laporan)

1. **Lingkup kabupaten** — jalur tak melintasi batas kab (matriks per kab);
   fasilitas eksisting lintas batas juga tak terlihat. Keputusan sadar
   (kelembagaan pendanaan kabupaten); varian bebas-batas = matriks sparse
   per provinsi, belum dibangun.
2. Gap FEASIBLE besar pada model besar dengan WAKTU_MAKS 30 dtk — sertifikat
   longgar, bukan solusi buruk; naikkan batas waktu bila butuh sertifikat.
3. Kalibrasi Cold Storage ×16 ruta/ton seragam (abaikan jenis CS/ABF dan
   produktivitas per provinsi 2–5 ton/ruta).
4. `klasifikasi_ikan.json` belum divalidasi ahli; `kom_prov_*` = ruta ST2023
   (bukan ton); volume diperlakukan aditif antar desa.
5. OSRM publik: snap ke jalan terdekat; 52 desa TANPA koordinat dikeluarkan
   (bukan koordinat cacat — poligonnya tidak ada di Wilkerstat, jadi tak punya
   baris `geo/`; ditelusuri 4 Sep 2026).
6. Parameter kebijakan (V_min/T_maks/β semua varian) berstatus "Belum
   ditetapkan" di GLOSSARY kecuali pilihan model (MILP, opsi B, K2) yang
   sudah diketok user.

## 9. Reproduksi

```
../../../.venv/bin/python bangun_matriks.py <idkab ...>      # sekali per kab
../../../.venv/bin/python mesin_milp.py <idkab ...>          # varian Komoditas
../../../.venv/bin/python gudang_kopdes.py --opsi B <idkab ...>
../../../.venv/bin/python cold_storage.py --kandidat K2 <idkab ...>
../../../.venv/bin/python jalur_wisata.py --kandidat W6 <idkab ...>
../../../.venv/bin/python uji_jalur.py            # keempat varian sekaligus
../../../.venv/bin/python uji_jalur.py <berkas_hasil.json>   # satu berkas
```
Checkpoint per kabupaten (hapus untuk hitung ulang); protokol rerun data baru
di README. Dependensi: ortools, spopt, libpysal, numpy, pandas, scipy, sklearn.
Catatan shell: zsh tidak memecah `$VAR` jadi argumen — tulis daftar idkab
eksplisit.
