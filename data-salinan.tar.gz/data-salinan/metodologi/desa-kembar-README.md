# desa-kembar — komponen ML SIMPUL DESA (pencarian desa serupa / sentra via kNN)

Desa Kembar = *k-nearest-neighbour* berbasis contoh: tiap desa diringkas jadi
vektor fitur, desa "kembar" = tetangga terdekat di ruang itu; sekaligus dipakai
sebagai penebak sentra komoditas (probabilitas dari tetangga). Data masukan:
`../../panen/gabung/desa_ml.csv`.

## Model produksi

**v3 tanpa-koordinat** (`model_desa_kembar_v3.json`; ringkasan resmi:
`papan_skor.json`): kNN k=12, weights=distance, p=1, 16 kolom berbobot
(campuran mentah + persentil per kabupaten), pipeline
log1p → imputasi median kab/prov → [z-score | persentil] per kabupaten →
bobot kolom → kNN brute. Tanpa lat/lon — kembar berdasarkan PROFIL, bukan
desa sebelah.

Konfigurasi (kolom, bobot, hiperparameter) hasil pencarian nested
leave-one-province-out pada 3 provinsi awal (33 Jateng, 52 NTB, 73 Sulsel) —
lihat `eksperimen_knn2.py`. AP uji nested saat itu: rerata **0,691**
(tersimpan di blok `riwayat_nested_33_52_73` dalam berkas model).

## Data terkini (2026-09-04, basis pasca Tahap A+B): 5 provinsi

17.467 desa, 89 kabupaten, 374 pasangan (kabupaten × komoditas). Provinsi 18
(Lampung) dan 63 (Kalsel) tidak pernah dilihat saat seleksi konfigurasi —
angka mereka uji murni.

| Provinsi | AP | p@25 |
|---|---|---|
| 18 Lampung (uji murni) | 0,674 | 0,619 |
| 33 Jateng | 0,648 | 0,598 |
| 52 NTB | 0,759 | 0,684 |
| 63 Kalsel (uji murni) | 0,813 | 0,720 |
| 73 Sulsel | 0,723 | 0,658 |
| **Rerata** | **0,723** | **0,656** |

ROC-AUC pooled LOO 0,937; F1 pada ambang-latih 0,655.

## Spesifikasi teknis model (v3 tanpa-koordinat — mesin yang ada saat ini)

Rujukan lengkap: apa persisnya yang dihitung `latih_desa_kembar.py`
(konfigurasi beku di `model_desa_kembar_v3.json`; fungsi muat/fitur dipinjam
dari `eksperimen_knn2.py`).

### 1. Data masukan dan satuan analisis

- Berkas: `../../panen/gabung/desa_ml.csv` — satu baris = satu desa.
- Satuan evaluasi = pasangan **(kabupaten × target)**. Target = 7 kolom
  peringkat komoditas provinsi (ST2023): `kom_prov_tp_02`, `horti_02`,
  `kebun_01`, `kebun_02`, `kebun_05`, `ternak_01`, `ikan_01` — komoditas
  aslinya beda per provinsi (mis. `kebun_01` = Kelapa di Jateng, Tembakau di
  NTB, Cengkeh di Sulsel; kamus di `../../panen/komoditas/<prov>.json`).
- Label per (kabupaten, target): desa "sentra" = 25 teratas menurut jumlah
  ruta, dipangkas yang < 20 ruta; pasangan valid butuh ≥ 15 desa sentra.
  Data terkini: 374 pasangan valid, 89 kabupaten, 17.467 desa.

### 2. Fitur

- Kolam kandidat 96 kolom = **48 kolom mentah** + **48 versi persentil**:
  - Mentah: `log1p` (untuk kolom berekor panjang — daftarnya di dict
    `KANDIDAT` `eksperimen_knn2.py`) → imputasi median berjenjang
    (kabupaten → provinsi → global).
  - Persentil (`pr:*`): peringkat 0–100 dalam kabupaten (rank average).
  - Seluruh 96 kolom (mentah + persentil) lalu di-`StandardScaler` per
    kabupaten; kolom konstan dalam kabupaten menjadi 0.
- **lat/lon DILARANG** sebagai fitur — kembar berdasarkan PROFIL, bukan
  kedekatan geografis. `koperasi_tani` dikeluarkan saat pencarian v3 karena
  waktu itu nol semua — 4 Sep 2026 terbukti itu bug kunci `panen_ml.py`, dan
  kolomnya kini terisi; konfigurasi v3 TIDAK dicari ulang. `is_*` diwakili
  `share_utp_*` + `jlh_utp`/`n_ruta_tani` sebagai proxy ukuran.
- 16 kolom terpilih model final (dengan bobot pengali):

| Kolom | Bobot | Kolom | Bobot |
|---|---|---|---|
| `pr:jlh_utp` | 1 | `n_ruta_tani` | 1 |
| `pr:elevasi_m` | 1 | `tl_tegalan` | 1 |
| `km_lurus_ke_pusat_kota` | **0,25** | `pr:share_utp_holti` | 1 |
| `pr:share_utp_kebun` | 1 | `pr:tl_kebun_campuran` | 1 |
| `share_utp_ikan` | **2** | `pr:n_ruta_tani` | 1 |
| `share_utp_ternak` | **2** | `pr:km_lurus_ke_pusat_kota` | 1 |
| `jlh_utp` | **2** | `pr:menit_ke_pelabuhan` | 1 |
| `share_utp_tp` | 1 | `share_utp_kebun` | 1 |

### 3. Model dan cara menyekor

- `KNeighborsClassifier`/`NearestNeighbors` sklearn, `algorithm="brute"`,
  metrik Minkowski **p=1** (jarak Manhattan), **k=12**,
  **weights="distance"**; ruang fitur = 16 kolom × bobot di atas.
- Pool tetangga = desa SEKABUPATEN (kembar dicari di kabupaten sendiri).
- Skor sentra desa i (leave-one-out; diri sendiri otomatis keluar):
  `s_i = Σ_j (label_j / d_ij) / Σ_j (1 / d_ij)` atas 12 tetangga terdekatnya
  (d dipagari ≥ 1e-9). Satu fit per kabupaten, skor semua target sekaligus
  (label beda per target, ruang fitur sama).
- "Desa kembar" untuk tampilan = tetangga terdekat di ruang yang sama.

### 4. Pencarian yang melahirkan v3 (nested, sudah selesai — tidak diulang)

Protokol leave-one-province-out pada 33/52/73; seleksi kolom, hiperparameter,
dan bobot HANYA di 2 provinsi latih tiap fold. Empat ronde per fold:
R1 SFFS pada 48 kolom mentah → R2 SFFS pada pool 96 → R3 sweep k×weights×p
(grid k {5,8,10,12,15,20}, p {1,2}, weights {distance,uniform}) → R4 bobot
kolom coordinate-ascent {0,25 · 0,5 · 1 · 2 · 4}; maksimum 16 kolom.
AP uji nested naik 0,671 → 0,691 (R1→R4); konfigurasi final = konsensus
antar fold di-refit pada seluruh data. Jejak: `hasil_eksperimen_knn2.json`.

### 5. Validasi terkini (konfigurasi beku, data 5 provinsi)

| Provinsi | AP | p@25 |
|---|---|---|
| 18 Lampung (**uji murni** — tak pernah dilihat pencarian) | 0,674 | 0,619 |
| 33 Jateng (in-search) | 0,648 | 0,598 |
| 52 NTB (in-search) | 0,759 | 0,684 |
| 63 Kalsel (**uji murni**) | 0,813 | 0,720 |
| 73 Sulsel (in-search) | 0,723 | 0,658 |
| **Rerata** | **0,723** | **0,656** |

ROC-AUC pooled LOO 0,937. Ambang keputusan biner: grid 0,02–0,90 langkah
0,02, dipilih per fold HANYA di provinsi latih (terpilih 0,32) →
F1 0,655, presisi 0,609, recall 0,707 (TP 6.390 · FP 4.096 · FN 2.650 ·
TN 67.313). Angka nested historis 3 provinsi (AP 0,691) tersimpan di blok
`riwayat_nested_33_52_73` berkas model — jangan dibandingkan langsung dengan
angka in-search di tabel.

### 6. Determinisme dan batas

- Rerun produksi (`latih_desa_kembar.py`) deterministik penuh — tanpa
  komponen acak (brute kNN + konfigurasi beku).
- Skor bermakna DALAM kabupaten (pool tetangga & normalisasi per kabupaten);
  jangan bandingkan skor antar kabupaten.
- Konfigurasi dicari pada 3 provinsi; klaim terkuat = performa uji murni
  Lampung/Kalsel (0,674/0,813). Pencarian ulang penuh (`eksperimen_knn2.py`,
  30–90 menit) hanya bila ingin menantang konfigurasi dengan data yang jauh
  lebih besar.

## Rerun saat ada data baru

Setiap kali `desa_ml.csv` diperbarui (provinsi bertambah / data direvisi):

```
cd data/machine-learning/desa-kembar
../../../.venv/bin/python latih_desa_kembar.py     # ± beberapa detik
```

Skrip membaca konfigurasi beku dari `model_desa_kembar_v3.json`, menghitung
ulang seluruh metrik pada data terkini, lalu menulis kembali berkas model dan
`papan_skor.json`. Konfigurasi tidak diubah. Ulangi pencarian penuh
(`eksperimen_knn2.py`, 30–90 menit per 3 provinsi) hanya bila ingin menantang
konfigurasi v3 dengan data yang jauh lebih besar.

## Peta berkas

| Berkas | Isi |
|---|---|
| `latih_desa_kembar.py` | Rerun produksi: evaluasi konfigurasi v3 beku pada `desa_ml.csv` terkini → `model_desa_kembar_v3.json`, `papan_skor.json`. |
| `eksperimen_knn2.py` | Pencarian yang melahirkan v3 (SFFS pool 96 kolom, sweep k/weights/p, bobot coordinate-ascent) → `hasil_eksperimen_knn2.json`; juga dipakai `latih_desa_kembar.py` sebagai pustaka (muat data, fitur, AP). |
| `hasil_eksperimen_knn2.json` | Keluaran mentah pencarian v3 (jejak per fold). |
| `model_desa_kembar_v3.json` | Konfigurasi model produksi + validasi terkini + riwayat nested 33/52/73. |
| `papan_skor.json` | Metrik resmi model produksi pada data terkini, per provinsi. |

Model kalah (v1 ruang persentil F21, v2 sklearn 12 kolom AP 0,635) beserta
notebook, skrip eksperimen, dan keluaran mentahnya diarsipkan ke
`../arsip/desa-kembar/` — tidak dipakai produksi.

Komponen saudara: `../citra-potensi-desa/` (skoring potensi komoditas,
protokol uji tertahan lintas kabupaten/provinsi — lihat README-nya).
