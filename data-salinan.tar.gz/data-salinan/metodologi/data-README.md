# `data/` — Lapisan Data SIMPUL DESA

Lapisan data proyek **SIMPUL DESA** (Sistem Intelijen Potensi dan Kesiapan
Ekonomi Desa): seluruh panen data mentah, tabel gabungan, model machine
learning, dan fitur produk yang dikonsumsi dasbor. Berdiri sejajar dengan tiga
komponen lain di akar proyek:

```
simpul-desa/
├── app/          → dasbor Next.js (konsumen akhir data)
├── data/         → folder ini: panen data + machine learning + fitur
├── dokumentasi/  → situs dokumentasi Docusaurus
└── api/          → layanan FastAPI (konsumen keluaran data/)
```

---

## Status: FINAL

**Dibekukan 5 September 2026 · dua perubahan metode diketok 6 September 2026.**
Siap dipakai membangun `app/`.

Ritus pembekuan dijalankan ulang sesudah perubahan terakhir; keluaran mentahnya
di [`BUKTI-VERIFIKASI.md`](./BUKTI-VERIFIKASI.md) supaya klaim "sudah
diverifikasi" bisa **diperiksa**, bukan dipercaya begitu saja:

| uji | hasil |
|---|---|
| `cek_panen.py` | 17.467 desa · tepat 4 CURIGA hulu yang sudah dikenal, nol temuan baru |
| `uji_jalur.py` | exit 0 · 23.318 unit · nol pelanggaran kendala keras |
| `bangun_peta_peran.py` | ketiga keluaran byte-identik saat diulang |
| konsistensi cacah | `desa_ml` = `peta_peran` = kartu = indeks = **17.467** |

Beku berarti **angkanya tidak lagi bergerak tanpa keputusan**, bukan berarti
sempurna. Yang sengaja dibiarkan terbuka dan tercatat di `TRACK.md`: dimensi
wisata berhenti di tiga provinsi LEMAH sehingga skornya **tidak** masuk Skor
Potensi; cacat hulu Wilkerstat di tiga kabupaten; tiga kode Dagri yang masih
bisa ditambal; serta `../GLOSSARY.md` dan tampilan dasbor milik sesi lain.

Membangun ulang boleh, asal ritusnya diulang dan `BUKTI-VERIFIKASI.md`
diperbarui.

## Cakupan

- **5 provinsi percontohan**: Lampung (18), Jawa Tengah (33), NTB (52),
  Kalimantan Selatan (63), Sulawesi Selatan (73)
- **97 kabupaten/kota** — tiap sumber dipanen per kabupaten, satu berkas per
  kabupaten berpola `<idkab>_<slug>.csv` (contoh `7311_bone.csv`)
- **17.467 wilayah** pada tabel induk `panen/gabung/desa_ml.csv` (127 kolom).
  Seluruh model dan fitur berdiri di atas basis yang sama.

## Yang dikonsumsi dasbor

Lima keluaran ini adalah titik masuk `app/`; sisanya bahan antara.

| keluaran | isi |
|---|---|
| `fitur/kartu-ekonomi-desa/keluaran/kartu/<idkab>.json` | 17.467 kartu, 97 berkas, 11 seksi per kartu |
| `fitur/kartu-ekonomi-desa/keluaran/indeks.json` | 17.467 baris ringkas untuk daftar & pencarian |
| `fitur/peta-peran/keluaran/peta_peran.{csv,json}` | Skor Potensi, Skor Kesiapan, zona penanganan |
| `machine-learning/citra-potensi-desa/v5/produksi/indeks.json` | 57 sel LAYAK — skor komoditas per desa |
| `machine-learning/jalur-ekonomi/varian-*/hasil_*.json` | empat varian penempatan aset bersama |

## Struktur

```
data/
├── README.md · BUKTI-VERIFIKASI.md
├── panen_ml.py          → pemanen semua sumber (BPS, IDM, Jadesta, OSM, dll)
├── cek_panen.py         → validator panen (deteksi berkas RUSAK/CURIGA)
├── tambal_master.py     → penambal master dari poligon Wilkerstat
│
├── panen/               162 MB · DATA MENTAH per sumber, per kabupaten
│   ├── master/          → daftar desa + kode Dagri            (97 CSV)
│   ├── geo/             → centroid, luas, tutupan lahan, POI  (97 CSV)
│   ├── idm/             → Indeks Desa Membangun 2024          (97 CSV)
│   ├── infrastruktur/   → landmark pertanian (lumbung/giling/koperasi)
│   ├── jadesta/         → desa wisata Jadesta Kemenpar        (97 CSV)
│   ├── st2023/          → Sensus Pertanian 2023               (97 CSV)
│   ├── batas_desa/      → poligon batas desa            (97 GeoJSON, ±124 MB)
│   ├── komoditas/       → kamus komoditas per provinsi   (5 JSON)
│   ├── gabung/desa_ml.csv → TABEL INDUK 17.467 × 127; masukan semua model
│   └── eksternal/       → di LUAR pipeline utama, tidak masuk desa_ml.csv
│       ├── cold-storage/  titik CS + produksi perikanan KKP
│       ├── wisata/        registri Sisparnas, DTW, bobot desa wisata
│       └── perikanan/     69 kampung nelayan Kepmen-KP
│
├── machine-learning/     59 MB · tiga komponen model
│   ├── citra-potensi-desa/
│   │   ├── v5/          → MESIN PRODUKSI katalog komoditas
│   │   │   ├── keluaran/  hasil validasi per sel (checkpoint)
│   │   │   └── produksi/  57 sel LAYAK + indeks.json
│   │   └── wisata/      → varian wisata: puncaknya 3 provinsi LEMAH, tak satu
│   │                      pun LAYAK, jadi TIDAK masuk Skor Potensi
│   │                      (BRIEF-WISATA.md §7-8)
│   ├── desa-kembar/     → kNN desa serupa, AP 0,7234 (model_desa_kembar_v3.json)
│   └── jalur-ekonomi/   → penempatan aset bersama (MILP CP-SAT)
│       ├── matriks/     → 97 matriks waktu tempuh OSRM (.npz) — MAHAL
│       └── varian-{komoditas,gudang-kopdes,cold-storage,wisata}/
│                        → hasil_*.json (final) + checkpoint/ (WAJIB ada:
│                          runner merakit hasil_*.json dari isinya)
│
├── fitur/                91 MB · yang dirakit dari data + model
│   ├── peta-peran/      → Skor Potensi, Skor Kesiapan, zona
│   └── kartu-ekonomi-desa/ → 17.467 kartu profil
│
└── arsip/                31 MB · SELURUH jejak, tidak dibaca skrip mana pun
    ├── eksperimen/      → catatan keputusan untuk rumus yang BERLAKU:
    │   ├── koperasi/      kenapa koperasi_tani masuk SK_KELEMBAGAAN
    │   └── osm/           kenapa aturan "nol POI = hilang" dibuang
    └── (lainnya)        → keluaran lama, kandidat kalah uji, log, cache
```

`arsip/` memuat **dua jenis isi yang berbeda derajatnya**, dan bedanya perlu
dijaga: `arsip/eksperimen/` menjelaskan rumus yang **masih berlaku** beserta
varian yang kalah — ia dirujuk komentar kode sebagai alasan; sisanya jejak yang
sudah **tidak dipakai sama sekali**. Tak satu pun dibaca skrip saat berjalan,
tetapi `arsip/eksperimen/` tidak boleh dihapus selama rumus yang dijelaskannya
masih dipakai.

## Alur data

```
panen_ml.py  →  panen/<sumber>/<idkab>_<slug>.csv  →  panen/gabung/desa_ml.csv
                                                          │
                    ┌─────────────────────────────────────┼───────────────────┐
                    ▼                                     ▼                   ▼
             desa-kembar (kNN)               citra-potensi-desa (skoring)   jalur-ekonomi
             model_desa_kembar_v3.json       v5/produksi/ + v5/keluaran/    (MILP + matriks OSRM)
                    │                                     │                 varian-*/hasil_*.json
                    │                                     │                   │
                    │                        ┌────────────┴───────────────────┘
                    │                        ▼
                    │                 fitur/peta-peran  (v5/produksi + matriks tt)
                    │                        │
                    └────────────────────────┴──→  fitur/kartu-ekonomi-desa
                                                   (semua komponen + peta-peran)
```

1. **Panen** — `panen_ml.py` menarik tiap sumber per kabupaten. Berkas yang
   sudah ada dilewati; `--ulang` memaksa unduh ulang.
2. **Validasi** — `cek_panen.py` menandai `RUSAK`/`CURIGA` lengkap dengan
   perintah penambalnya.
3. **Gabung** — `panen_ml.py gabung` merakit `desa_ml.csv`.
4. **Model** — tiga komponen membaca `desa_ml.csv` (plus matriks OSRM untuk
   jalur-ekonomi) lalu menulis ke foldernya masing-masing.
5. **Fitur** — `peta-peran` lebih dulu, `kartu-ekonomi-desa` menyusul.
   Urutan ini wajib.

`panen/eksternal/` berada **di luar rantai ini** — tidak masuk `desa_ml.csv`,
dibaca langsung oleh varian Jalur Ekonomi dan lapisan fakta Kartu.

## Cara menjalankan

Semua skrip memakai venv proyek (`simpul-desa/.venv`):

```bash
cd simpul-desa/data
../.venv/bin/python cek_panen.py                    # cek kesehatan panen
../.venv/bin/python panen_ml.py master --kab 7311   # panen ulang satu sumber
../.venv/bin/python panen_ml.py gabung              # rakit ulang desa_ml.csv
```

Skrip ML dan fitur dijalankan **dari foldernya sendiri** karena memakai path
relatif; perintah persisnya ada di README tiap komponen. Rebuild fitur:

```bash
cd fitur/peta-peran        && ../../../.venv/bin/python bangun_peta_peran.py
cd ../kartu-ekonomi-desa   && ../../../.venv/bin/python bangun_kartu.py
```

> Shebang di `.venv/bin/` sudah ditulis ulang jadi wrapper relatif, sehingga
> venv tetap berfungsi walau folder proyek dipindah. Untuk pip tetap pakai
> `.venv/bin/python -m pip ...`.

## Dua keputusan metode yang perlu diketahui pembaca hilir

**1. Nol POI OSM berarti NOL, bukan "tidak terpetakan"** (6 Sep 2026). Enam
kolom POI OSM nyaris kosong — `poi_logistik` nol di 97,5% wilayah, `poi_niaga`
79,4%, dan 50,7% desa nol di keenamnya. Dulu nol dijadikan "hilang" lalu
bobotnya dibagi ulang; akibatnya 55% wilayah kehilangan SK_AMENITAS dan wilayah
yang datanya kosong justru diuntungkan. Sesudah aturan itu dibuang: kekosongan
turun ke 0,3%, Belum Terpetakan 474 → 104, dan SK jauh lebih baik mengenali
kunci luar. Trade-off-nya nyata dan dicatat di `fitur/peta-peran/README.md`.

**2. Tidak semua tema dominan sama kuatnya.** Kolom `sumber_dominan`
menyatakannya di data, bukan hanya di dokumen:

| nilai | arti | wilayah |
|---|---|---|
| `citra` | model v5, lulus uji tertahan antar kabupaten | 11.458 |
| `heuristik-tervalidasi` | heuristik yang menang di kunci luar (SUB_tangkap, kunci Kepmen-KP) | 1.085 |
| `heuristik-belum-teruji` | **Simpul Logistik — belum ada kunci yang mendukung** | 3.733 |
| `fallback-heuristik` | provinsi tanpa sel v5 LAYAK, jatuh ke pangsa ruta | 1.139 |

Jangan sajikan label `heuristik-belum-teruji` setara dengan `citra`.

## Aturan folder ini

- **Jangan hapus** `panen/` dan `machine-learning/jalur-ekonomi/matriks/` —
  matriks OSRM 97 kabupaten mahal dihitung ulang (butuh server OSRM).
- **`panen/eksternal/` dikurasi manual, sebagian tanpa pemanen** — `perikanan/`
  seluruhnya disalin tangan dari lampiran Kepmen-KP, dan sumber "internal"
  portal KKP butuh login. Paling sulit dipulihkan bila hilang.
- **`varian-*/checkpoint/` WAJIB ada.** Runner merakit ulang `hasil_*.json`
  dari SELURUH isinya tiap dijalankan; menjalankannya saat checkpoint terisi
  sebagian akan menimpa berkas produksi dengan hasil separuh jadi. Ini pernah
  terjadi — `hasil_komoditas.json` sempat menyusut jadi 2 kabupaten.
- **`arsip/` disimpan sengaja** sebagai bukti bahwa pilihan model diambil
  dengan angka. Tak satu pun dibaca skrip, tapi jangan dibersihkan tanpa
  keputusan.
- **Tiga hal bernama/tampak arsip yang TETAP HIDUP**: `varian-*/checkpoint/`,
  `panen/eksternal/wisata/arsip_wisata_bobot_desa_v1_436.csv` (masukan join
  anti-sirkular), dan `arsip/eksperimen/` (catatan keputusan rumus yang
  berlaku — dirujuk komentar kode).
  Rinciannya di `arsip/README.md`.
- `__pycache__` dan `.DS_Store` boleh dihapus kapan saja.

## Rujukan lebih dalam

| Topik | Berkas |
|---|---|
| **Bukti pembekuan + ritus verifikasi** | `BUKTI-VERIFIKASI.md` |
| Konvensi panen + tabel induk | `panen/README.md` |
| Peta tiga komponen ML + siapa konsumsi apa | `machine-learning/README.md` |
| Skoring potensi komoditas | `machine-learning/citra-potensi-desa/README.md` |
| Katalog v5 — cara re-run | `machine-learning/citra-potensi-desa/v5/README.md` |
| Varian wisata (riwayat lengkap, berhenti di LEMAH) | `machine-learning/citra-potensi-desa/wisata/BRIEF-WISATA.md` |
| Desa Kembar (kNN) | `machine-learning/desa-kembar/README.md` |
| Jalur Ekonomi — konsep | `machine-learning/jalur-ekonomi/README.md` |
| Jalur Ekonomi — model & metrik | `machine-learning/jalur-ekonomi/MODEL.md` |
| Peta Peran — Skor Potensi & Kesiapan | `fitur/peta-peran/README.md` |
| Kartu Ekonomi Desa — 11 seksi per kartu | `fitur/kartu-ekonomi-desa/README.md` |
| Catatan keputusan rumus yang berlaku | `arsip/eksperimen/README.md` |
| Jejak yang tidak dipakai produksi | `arsip/README.md` |
| Data cold storage KKP | `panen/eksternal/cold-storage/README.md` |
| Data wisata eksternal | `panen/eksternal/wisata/README.md` |
| Kampung nelayan Kepmen-KP | `panen/eksternal/perikanan/README.md` |
| Anomali data Bone | `machine-learning/citra-potensi-desa/catatan-anomali-bone.md` |
| Istilah resmi produk | `../GLOSSARY.md` |
| Papan tugas folder ini | `./TRACK.md` |
