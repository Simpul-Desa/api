# Kartu Ekonomi Desa

Fitur inti SIMPUL DESA: profil ekonomi lengkap tiap desa **tanpa satu pun
kuesioner** — "jiwa" tiap desa dalam satu kartu. 17.467 kartu (desa +
kelurahan; basis pasca Tahap A+B, 4 Sep 2026), 97 kabupaten/kota, 5 provinsi. Istilah mengikuti `../../../GLOSSARY.md`
(termasuk kode kosong dan Rekomendasi Aksi yang ditetapkan 4 Sep 2026).

## Berkas

| Berkas | Isi |
|---|---|
| `bangun_kartu.py` | perakit kartu → `keluaran/` |
| `keluaran/kartu/<idkab>.json` | 97 berkas, satu per kabupaten: `{idkab, nmkab, n_wilayah, kartu:[...]}` |
| `keluaran/indeks.json` | 17.467 baris ringkas untuk daftar/pencarian dasbor |
| `keluaran/sumber.json` | daftar sumber data + tahun per lapisan |

## Menjalankan ulang

Seluruh `keluaran/` regenerable. Prasyarat: **jalankan `fitur/peta-peran`
lebih dulu** (kartu membaca `peta_peran.csv`), dan pastikan `desa_ml.csv`,
`v5/produksi/`, serta empat `hasil_*.json` Jalur Ekonomi mutakhir.

```bash
cd ../peta-peran && ../../../.venv/bin/python bangun_peta_peran.py   # bila data berubah
cd ../kartu-ekonomi-desa && ../../../.venv/bin/python bangun_kartu.py   # ~2 mnt
```

## Sebelas seksi per kartu

| Seksi | Isi | Sumber |
|---|---|---|
| `identitas` | nama, Desa•Kec•Kab•Prov, kode BPS + Dagri, tipe desa/kelurahan, lon/lat, luas | SIG BPS (bridging) |
| `peta_peran` | zona + nomor, keyakinan, SP/SK, **desil + peringkat dalam kabupaten**, ambang, kelengkapan bukti, alasan Belum Terpetakan | fitur/peta-peran |
| `rekomendasi_aksi` | 1–2 kalimat dari aturan tetap: frasa zona × frasa tema dominan × status program; Belum Terpetakan → perintah melengkapi data | mesin (bukan LLM) |
| `potensi` | tema dominan + **status validasinya** (`citra` / `heuristik-tervalidasi` / `heuristik-belum-teruji` / `fallback-heuristik` — lihat `peta-peran/README.md`; label `heuristik-belum-teruji` menandai Simpul Logistik yang belum punya kunci pendukung dan WAJIB tampil, bukan disembunyikan), **detail sel pemenang** (komoditas, skor100, peringkat kab, AP uji tertahan), 8 persentil sub-skor | Citra Potensi v5 + peta-peran |
| `kesiapan` | 4 komponen SK + angka mentah di baliknya: IDM/IKS/IKE/IKL+status 2024, lumbung/penggilingan/per-1000-ruta, 6 jenis POI | IDM, ST2023, OSM |
| `biofisik` | tutupan lahan (kelas >0), elevasi, relief, pantai | Tutupan lahan BPS, SRTM, OSM |
| `pertanian` | ruta tani, unit usaha, 6 subsektor, milenial/jasa/teknologi/urban-farming, **komoditas unggulan ber-nama** (top-5 ruta, kamus per provinsi) | ST2023 + panen/komoditas |
| `logistik` | menit ke pusat kota/bandara/pelabuhan **dengan nama acuannya**, km lurus, sentralitas OSRM | OSRM + matriks tt |
| `jalur_ekonomi` | peran per varian (Komoditas — bisa lebih dari satu jalur —, Gudang Kopdes, Cold Storage, Wisata): Desa Poros/Sejalur, poros pelayan, menit ke poros, volume. **Selalu klaim model**: khusus Cold Storage hanya unit BARU usulan solver yang masuk sini; desa yang penugasannya jatuh ke gudang beku yang sudah berdiri dilaporkan sebagai fakta (`fakta_program.cold_storage_terlayani`), bukan sebagai peran | hasil ML Jalur Ekonomi |
| `desa_kembar` | 3 desa termirip (kNN v3 setia — fitur & skala dari `eksperimen_knn2`), % kemiripan (definisi GLOSSARY: 1 − d/p95 jarak kabupaten), zona kembarnya | model Desa Kembar |
| `fakta_program` | Jadesta (kategori+atraksi/paket/homestay), **registri desa wisata Sisparnas** (1.141 desa; saring `gagal`/`terdekat`>10 km), **n daya tarik wisata** (2.132 desa; hanya titik `pip` atau `terdekat`≤5 km — placeholder Jakarta tersaring), Kampung Budidaya KKP, Kampung Nelayan Kepmen-KP, cold storage eksisting (`cold_storage_eksisting` = unit yang berdiri di desa itu sendiri; `cold_storage_terlayani` = desa berada dalam jangkauan unit eksisting menurut penugasan solver — keduanya berbeda dan bisa muncul bersama); bendera **`belum_tersentuh`** | registri publik — **tidak pernah masuk skor** |
| `mutu_data` | punya geometri/ST2023/IDM, kelengkapan bukti SK | internal |

Nilai kosong SELALU membawa kode alasan (`{"nilai": null, "kosong": ...}`):
`TIDAK-DINILAI` (kelurahan tanpa IDM) · `TIDAK-TERPETAKAN` (nol OSM) ·
`TIDAK-BERLAKU` (tangkap di kabupaten tanpa pantai) · `TIDAK-ADA-DATA`
(52 desa tanpa geometri). JSON ditulis `allow_nan=False` — NaN tidak mungkin
lolos.

## Angka hasil (4 Sep 2026)

- 17.467 kartu; 15.609 punya peran Jalur Ekonomi; semua punya 3 Desa Kembar.
- Peran Cold Storage: **254 kartu**, seluruhnya bersandar pada unit BARU
  usulan solver (32 Desa Poros + 222 Desa Sejalur). Tidak satu pun dari 32
  Desa Poros itu berada di desa yang sudah punya cold storage — klaim
  modelnya bersih.
- Keterlayanan unit lama: **76 kartu** membawa
  `fakta_program.cold_storage_terlayani` (9 tuan rumah unitnya sendiri, 67
  desa sekitar). Ini FAKTA, bukan peran — keputusan 4 Sep 2026. Alasannya
  dua arah: menyebut desa tempat gudang lama berdiri sebagai "Desa Poros"
  memberi model kredit atas sesuatu yang tidak ia temukan, tetapi
  menghilangkannya sama sekali membuat 67 desa sekitar terbaca seolah belum
  terjangkau rantai dingin — padahal justru karena sudah terjangkau maka
  tidak diusulkan unit baru di sana (inilah wawasan yang membuat kandidat K2
  menang atas K1; lihat `jalur-ekonomi/MODEL.md` §4).
- **1.229 desa tersentuh ≥1 registri program** (Jadesta 436 + Sisparnas 1.141 +
  Kampung Budidaya + Kampung Nelayan 69) — sisanya membawa kalimat "belum
  tersentuh satu pun registri yang terpantau"; untuk Zona Pemerintah kalimat
  itulah pesan utamanya. (Angka sebelum registri Sisparnas masuk 4 Sep sore:
  514.)
- Sanity: kartu Pageraji mereproduksi contoh naskah MVP §11.1 (IDM 0,7740
  Maju, 12,5 menit ke Purwokerto, dominan perkebunan-kelapa, Zona Pemerintah).

## Pelajaran referensi yang diadopsi (riset 4 Sep 2026)

IDM Kemendesa (aktor+urgensi menempel di rekomendasi) · SDGs Desa (skor wajib
didampingi volume+satuan mentah) · US Census QuickFacts (sel kosong berkode
alasan) · IMD England (desil+peringkat, bukan skor desimal) · ONS (sumber+
tahun per lapisan, caveat eksplisit). Berita/media sengaja kosong dulu
sebagai lapisan data (keputusan 4 Sep 2026).

## Data lama yang digantikan

Kartu prototipe lama (`SIMPUL DESA/demo/demo_data.json`, 585 desa) tercakup
penuh: seluruh medannya ada di sini plus detail sel v5 tervalidasi, sentralitas
OSRM, peran 4 varian Jalur Ekonomi, dan 3 lapisan fakta program baru.
