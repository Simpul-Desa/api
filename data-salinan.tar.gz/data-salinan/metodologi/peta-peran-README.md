# Peta Peran — Skor Potensi, Skor Kesiapan, dan zona penanganan

Fitur inti SIMPUL DESA: menempatkan tiap desa/kelurahan ke satu dari empat
zona penanganan (Zona Pemerintah, Zona Mitra, Zona Poros, Zona Bantuan) —
lihat `../../../GLOSSARY.md` untuk istilah sahnya. Cakupan: 17.467 wilayah,
97 kabupaten/kota, 5 provinsi (basis 4 Sep 2026 malam, pasca Tahap A+B).

## Berkas

| Berkas | Isi |
|---|---|
| `bangun_peta_peran.py` | menghitung SP, SK, zona → `keluaran/peta_peran.{csv,json}`, `ringkasan_kab.json` |
| `uji_peta_peran.py` | uji penemuan-kembali (baru vs metode lama), robustness, tipologi pembanding → `keluaran/uji_peta_peran.json` |
| `kunci_eksternal.json` | INPUT kurasi manual (jangan dihapus): kunci jawaban eksternal dari sumber publik internet, 11 klaster + URL |
| `eksperimen_tuning.py` | eksperimen penguat yang diukur lalu ditolak (jejak uji-tolak) → `keluaran/eksperimen_tuning.json` |

## Menjalankan ulang

Seluruh isi `keluaran/` regenerable; satu-satunya berkas yang dipelihara
tangan adalah `kunci_eksternal.json` di akar folder ini. Urutan dari folder
ini (data berubah? cukup ulangi dari langkah 1):

```bash
../../../.venv/bin/python bangun_peta_peran.py   # 1. skor + zona  (~1 mnt)
../../../.venv/bin/python uji_peta_peran.py      # 2. uji lama-vs-baru + robustness
../../../.venv/bin/python eksperimen_tuning.py   # 3. opsional: jejak uji-tolak
```

Prasyarat data: `panen/gabung/desa_ml.csv` terbangun, `citra-potensi-desa/v5/produksi/`
terisi (kalau sel v5 berubah, jalankan `v5/skor_produksi.py` dulu), dan matriks
`jalur-ekonomi/matriks/tt_*.npz` ada.

## Metode

### Skor Potensi (SP)

Delapan sub-skor tematik, masing-masing dipersentilkan dalam kabupaten
(0–100, peringkat rata-rata untuk seri); **SP = maksimum persentil**, dan
tema tempat maksimum tercapai menjadi *potensi dominan*. Maksimum — bukan
rerata — supaya desa spesialis tidak dihukum; preseden operator serupa
(anti saling-menghapus antar domain) dipakai IMD England.

- **6 sub-skor subsektor** (pangan, hortikultura, perkebunan, peternakan,
  perikanan, kehutanan): diambil dari **skor produksi Citra Potensi Desa v5**
  — hanya sel (provinsi × komoditas) berstatus LAYAK (AP uji tertahan ≥ 0,40,
  CI bootstrap). Per desa per subsektor = maksimum `skor100_dlm_kab` antar
  sel subsektor itu di provinsinya, sehingga potensi dominan bisa menyebut
  komoditasnya ("Perkebunan — Kelapa"). Provinsi tanpa sel LAYAK pada suatu
  subsektor memakai fallback heuristik pangsa ruta subsektor (min-maks per
  kabupaten). Kolom `sumber_dominan` mencatat `citra`/`heuristik`.
- **SUB_tangkap** (Perikanan Tangkap, ditambahkan 4 Sep 2026 dari hasil uji
  kunci Kepmen-KP): garis pantai (log1p) + pangsa ruta perikanan, min-maks
  per kabupaten; gerbang tematik kabupaten berpantai. Dipisah dari SUB_ikan
  karena sel v5 mengukur *budidaya* komoditas (nila/bandeng) — konstruk
  berbeda dari desa nelayan tangkap; uji kampung nelayan membuktikannya
  (lihat Hasil uji). SUB_ikan kini eksplisit bermakna Perikanan Budidaya.
- **SUB_simpul** (posisi logistik): heuristik — waktu tempuh OSRM ke pusat
  kota/pelabuhan/bandara (log1p, arah terbalik) + POI niaga & logistik OSM
  (log1p; nol = tidak terpetakan = hilang), min-maks per kabupaten, rerata
  komponen terukur.
- **Wisata tidak menyusun SP.** Temuan v5: potensi wisata tanpa-sinyal dari
  citra. Registri Jadesta dilampirkan sebagai lapisan fakta
  (`jadesta_kategori`; angka bobot turunan v1 sengaja tidak diikutkan — rumus
  bakunya v2 dihitung internal runner W6) sampai ada data potensi wisata teruji.

### Status validasi per tema — baca sebelum memakai `potensi_dominan`

Kolom `sumber_dominan` menyatakan seberapa kuat dasar tiap label, dan bedanya
besar. Ini ditegakkan 6 Sep 2026 supaya kelemahan tidak tersembunyi:

| nilai | arti | wilayah |
|---|---|---|
| `citra` | model Citra Potensi v5, **lulus uji tertahan** antar kabupaten (AP ≥ 0,40 + CI bootstrap) | 11.458 |
| `heuristik-tervalidasi` | heuristik yang **diuji dengan kunci luar dan menang** — SUB_tangkap, diuji dengan nama desa dari lampiran Kepmen-KP kampung nelayan | 1.085 |
| `heuristik-belum-teruji` | heuristik **tanpa kunci yang mendukungnya** — hanya SUB_simpul | 3.733 |
| `fallback-heuristik` | subsektor komoditas yang provinsinya tak punya sel v5 LAYAK, jatuh ke pangsa ruta | 1.139 |

**Simpul Logistik adalah tema dominan bagi 3.733 wilayah (21%) dan
BELUM TERVALIDASI.** Diuji dengan dua kunci luar yang bebas dari seluruh
masukannya — 665 desa ibu kota kecamatan dan 155 desa tuan rumah cold storage
operasional — hasilnya median persentil 37,4% dan 29,1%, dengan acak = 50% dan
SK total = 25,5%. Artinya ia membawa sedikit sinyal, tetapi jelas lebih lemah
daripada tema lain. Sebabnya diketahui: `poi_logistik` nol di 97,5% wilayah dan
`poi_niaga` di 79,4%, jadi praktis hanya waktu tempuh OSRM yang bekerja.

Jangan sajikan label Simpul Logistik setara dengan tema ber-`citra` tanpa
menyebut status ini.

Distribusi SP menumpuk tinggi by design (maksimum 8 persentil; median
teoretis maks-8-uniform ≈ 88,9) — ambangnya relatif, bukan absolut.

### Skor Kesiapan (SK)

Empat komponen bobot setara 0,25, tiap komponen 0–100 dalam kabupaten;
SK = rerata berbobot dengan **pembagi = jumlah bobot terukur** (wilayah tidak
dihukum karena datanya kosong; kelengkapan dicatat dan ditampilkan).

| Komponen | Penyusun | Catatan |
|---|---|---|
| SK_INDEKS | IDM 2024 | kelurahan tidak dinilai IDM → komponen hilang, sifatnya struktural |
| SK_KELEMBAGAAN | (lumbung + penggilingan + **koperasi_tani**) / 1.000 ruta tani, log1p; penyebut dihaluskan **max(ruta, 50)** | Koperasi MASUK sejak 5 Sep 2026. Alasan pembuangannya dulu ("kolom mati 100% nol") ternyata bug kunci `panen_ml.py`; setelah ditambal kolomnya berisi 1.155 titik di 860 desa. Diuji lebih dulu di `eksperimen-koperasi/`: korelasinya dengan dua landmark lain nyaris nol (0,05 Pearson) sehingga membawa informasi baru, dan 165 desa yang selama ini bernilai nol jadi terlihat. Penyebut dihaluskan karena satu landmark dibagi segelintir ruta tani memuncaki min-maks — cacat yang SUDAH ADA sebelumnya dan justru berkurang (rasio ekstrem 246 → 238) |
| SK_AMENITAS | POI layanan dasar + keuangan (log1p; **nol = NOL NYATA** sejak 6 Sep 2026) | Dulu nol diperlakukan "tidak terpetakan" lalu bobotnya dibagi ulang — akibatnya 55% wilayah kehilangan komponen ini, dan wilayah yang datanya kosong justru DIUNTUNGKAN (median SK 42,80 vs 41,14) meski lebih terpencil dan ber-IDM lebih rendah. Uji lima varian (`../../eksperimen-osm/`) menunjukkan pola monoton: makin banyak nol diperlakukan nyata, makin baik SK mengenali kunci luar. Kekosongan turun 55% → 0,3% |
| SK_KONEKTIVITAS | menit ke pusat kota (terbalik) + **sentralitas OSRM** (rerata menit ke seluruh desa se-kabupaten, dari matriks `tt_*.npz`, terbalik) + POI niaga | sentralitas = variabel baru, cakupan 99,7%, bebas bias liputan OSM |

### Zona

Ambang = **median kabupaten** per sumbu, dihitung hanya dari wilayah yang
kesiapannya terukur. Konsekuensi yang dinyatakan terbuka: tiap kabupaten
menghasilkan ±seperempat wilayah per zona (alat prioritisasi intra-kabupaten,
bukan label absolut; tidak sebanding antar kabupaten dan bukan pengganti
status IDM/Indeks Desa yang ambangnya absolut nasional).

- **Belum Terpetakan**: bukti kesiapan terukur ≤ 50% bobot → tidak diberi
  zona; alasannya dicatat (`alasan_belum_terpetakan`), komponen yang
  seharusnya ada tetap ditampilkan kosong, tidak disembunyikan. Ambang 50%
  lebih longgar dari preseden SDG Index (20% missing) dengan justifikasi:
  kekosongan IDM di kelurahan bersifat struktural (kelurahan memang tidak
  dinilai IDM), bukan missing acak.
- **Keyakinan rendah**: jarak < 2 poin ke salah satu ambang (≈ kuartil
  terbawah jarak-ke-ambang; pita 5 poin akan menandai separuh populasi
  karena distribusi SP rapat). Penempatan wilayah ini rapuh — wajib tampil.
- Tampilan skor: desil + peringkat dalam kabupaten, bukan desimal — selisih
  kecil tidak boleh ditafsirkan (praktik IMD England).

### Penanganan data (temuan inventaris 3 Sep 2026)

- 129 baris tanpa ST2023: `share_utp_*`/`kepadatan_ruta_tani` nol-palsu →
  di-mask jadi hilang.
- 52 baris tanpa geometri → Belum Terpetakan, alasan "tanpa geometri".
- `menit_ke_*` berekor ekstrem (maks 71 jam, rute ferry gagal) → log1p
  sebelum min-maks meredam pengaruh ekor.
- Tipe wilayah diturunkan dari segmen ke-4 kode Kemendagri (1 = kelurahan,
  2 = desa).

## Hasil uji (4 Sep 2026, `keluaran/uji_peta_peran.json`)

**Uji 1 — penemuan kembali sentra komoditas, kunci internal ST2023 ditahan.**
Evaluasi hanya di kabupaten-uji tiap sel v5 (model tidak pernah menyentuh
labelnya); pembanding = replikasi setia metode heuristik prototipe lama
(`SIMPUL DESA/data/build_scores.py`) pada data yang sama. 250 sel×kabupaten,
174 berpasangan (basis 17.467):

| Metrik (rerata) | Metode baru | Metode lama |
|---|---|---|
| Average precision | **0,51** | 0,28 |
| Presisi@25 | **0,49** | 0,24 |
| Recall@50 | **0,74** | 0,43 |
| Menang AP per pasangan | **151/174** | 23/174 |

**Uji 3 — robustness zona.** 66,4% wilayah tetap di zona yang sama pada
tiga skema bobot SK; mengganti normalisasi komponen SK min-maks → z-score:
85,1% zona sama; → persentil: 83,9% sama.

Angka 6 Sep 2026, sesudah aturan nol OSM diubah. **Ada trade-off yang harus
dibaca terbuka**: stabilitas terhadap skema BOBOT naik (64,97% → 66,42%),
tetapi stabilitas terhadap ganti NORMALISASI turun (z-score 90,11% → 85,06%;
persentil 86,92% → 83,87%). Sebabnya diketahui dan wajar: dulu 55% wilayah
dinilai hanya dari 3 komponen karena SK_AMENITAS hilang; kini hampir semua
memakai 4 komponen penuh, sehingga hasilnya lebih peka terhadap cara tiap
komponen dinormalkan. Lebih banyak masukan yang benar-benar terpakai berarti
lebih banyak yang bisa bergeser.

**Uji 4 — tipologi pembanding.** k-means (k=4) pada ruang (SP, SK) per
kabupaten sepakat 63,5% dengan zona median (6 Sep 2026; sempat 65,0% sebelum
aturan nol diubah) — kuadran median bukan artefak
satu algoritma, dan sisanya adalah harga keterbacaan ambang median.

**Uji 2 — kunci eksternal internet** (`kunci_eksternal.json`,
desa terdokumentasi publik dengan URL sumber; peringkat pada sub-skor
perkebunan se-kabupaten penuh):

| Klaster (n kunci / n desa dinilai) | Baru: median peringkat, top-50 | Lama: median peringkat, top-50 |
|---|---|---|
| Desa Devisa Lada Hitam, Lampung Timur — kunci resmi (6/264) | **#10,5** · 6/6 di top-50 | #11,5 · 6/6 |
| Sentra kopi Temanggung, mutu A (3/289) | **#38** · 3/3 di top-50 | #64 · 1/3 |
| Sentra kopi Lampung Barat, mutu campuran (3/136) | #49 · 2/3 | #65 · 1/3 |
| Gula kelapa Banyumas — ANEKDOT titik peristiwa (6/331) | #51,5 · 3/6 | **#48** · 3/6 |

Adendum perikanan (kunci terkuat secara hukum: nama desa dari kolom resmi
lampiran Kepmen-KP KALAJU/Kalamo/KNMP; plus Kampung Perikanan Budidaya KKP).
Putaran pertama menguji semua klaster pada SUB_ikan dan menemukan cacat
konstruk: desa nelayan *tangkap* dinilai dengan skor *budidaya* — median
peringkat Cilacap #153, Rembang #42, sementara metode lama (bahari dengan
`pantai_km`) #30,5 dan #11. Dari temuan itu tema perikanan dipecah dua
(SUB_ikan budidaya / SUB_tangkap pesisir) — putaran kedua, kampung nelayan
diuji pada SUB_tangkap:

| Klaster tangkap (n kunci / n dinilai) | SUB_tangkap: median, top-25 | Lama SP_BAHARI | SUB_ikan (sebelum) |
|---|---|---|---|
| Kampung Nelayan Lampung Timur (3/264) | **#3** · 3/3 | #7 | #6 |
| Kampung Nelayan Sumbawa (3/164) | **#3** · 3/3 | #4 | #5 |
| Kampung Nelayan Maros (4/~100) | **#4,5** · 4/4 | #5 | #7 |
| Kampung Nelayan Rembang (3/~290) | **#10** · 3/3 | #11 | #42 |
| Kampung Nelayan Cilacap (4/~280) | **#19,5** · 2/4 | #30,5 | #153 |

Setelah pemecahan, metode baru unggul/setara di SELURUH klaster tangkap.
Catatan mutu kunci: hanya klaster Maros yang campuran sumber (2/4 desa dari
berita KNMP resmi, bukan lampiran Kepmen — dicatat di `kunci_eksternal.json`;
disaring ke Kepmen-saja klaster itu gugur karena <3 desa, jadi dipertahankan
dengan anotasi). Empat klaster lain 100% lampiran Kepmen.
Klaster budidaya tetap di SUB_ikan: Kampung Lobster Lombok Timur median #8
(lama #4), Nila Salin Tayu #60 (lama #46) — dua-duanya tetap masuk top-15%
kabupaten; catatan: sel v5 nila Jateng dilatih pada nila air tawar sehingga
nila *salin* (payau) kurang terwakili — dicatat, tidak di-tune lagi tanpa
kunci tambahan.

Bacaan kunci perkebunan: pada kunci resmi terbersih (lada) kedua metode sama-sama kuat
(median peringkat ~11 dari 264, seluruh 6 desa di top-50); metode baru unggul
di kopi (kedua klaster); klaster Banyumas bukan roster resmi — daftar 25 desa
Devisa LPEI tidak dipublikasikan (temuan riset: LPEI hanya merilis agregat) —
sehingga 6 titik peristiwa (lokasi upacara ekspor, kantor koperasi, pabrik di
kota) dipakai sebagai anekdot, bukan ukuran recall. Klaster kopi menandakan
batas kunci "ketenaran": di kabupaten yang hampir seluruh desanya berkebun
kopi (Lampung Barat), desa yang terkenal ≠ desa berkonsentrasi tertinggi.
Kunci ADWI/WIA (±100 desa wisata, berjenjang) tersimpan di laporan riset untuk
uji lapisan wisata kelak; klaster kerajinan menunggu sub-skor ekonomi
non-pertanian.

**Uji 5 — zona × kunci eksternal** (validasi arah penempatan zona memakai
desa kunci terdokumentasi; `uji5_zona_kunci` di berkas hasil):

- Sebaran zona ±seperempat per kabupaten adalah gabungan konstruksi dan
  temuan: median membelah tiap sumbu 50/50 (by design — alat prioritisasi
  intra-kabupaten), tetapi empat kuadran hanya mendekati 25% karena SP dan SK
  empiris saling bebas (Spearman **+0,042**; besarnya tetap ~0) — bukti kedua sumbu mengukur hal
  berbeda, alasan Peta Peran perlu dua sumbu. Antar kabupaten proporsi Zona
  Pemerintah bervariasi 17–33%.
- 49 desa kunci terdokumentasi TIDAK tersebar seragam: Pemerintah 23 ·
  Mitra 19 · Bantuan 4 · Poros 3 — desa yang terlihat publik menumpuk
  di zona "sudah siap / sedang diintervensi", sesuai tesis sistem.
- Kecocokan zona harapan (8 klaster berlogika jelas): **20/37** per 6 Sep 2026,
  turun dari 23/37 sebelum aturan nol OSM diubah. Perubahannya kecil dan
  bercampur — Sumbawa membaik 2/3 → 3/3, sedangkan Lampung Timur 3/3 → 1/3,
  Nila Salin Tayu 3/8 → 2/8, dan Merah Putih 3/3 → 2/3. Mekanismenya diketahui:
  memasukkan 55% wilayah bernilai nol ke kolam min-maks menaikkan posisi desa
  yang MEMANG punya amenitas terhadap yang tidak, sehingga sebagian kampung
  nelayan bergeser dari Zona Pemerintah (SP tinggi, SK rendah) ke Zona Mitra
  (keduanya tinggi). Ini kerugian nyata pada kunci terkurasi, dan ditukar
  dengan perbaikan besar pada kunci luar yang lebih banyak: SK mengenali 665
  desa ibu kota kecamatan pada median persentil 37,5% → 25,5%. Trade-off ini
  disebut terbuka, bukan diklaim sebagai kemenangan bersih. Sorotan:
  Desa Devisa lada (sudah bermitra) → Zona Mitra 5/6; kampung nelayan
  program pemerintah → Zona Pemerintah: Maros 4/4, Lampung Timur 3/3,
  Sumbawa 2/3, Lobster Lotim 2/3. Ketidakcocokan yang justru informatif:
  klaster Cilacap 0/4 — kuncinya kelurahan kota (SK 76–78, sudah siap →
  Mitra), program KALAJU di sana memang membangun fasilitas di kampung kota
  yang mapan; Nila Salin Tayu 3/8 tersebar Mitra/Pemerintah/Bantuan.
- Batas prinsip validasi zona lewat internet: Zona Pemerintah didefinisikan
  "berpotensi tapi belum terlihat" — desa yang terdokumentasi justru sudah
  terlihat; proxy terbaiknya desa yang baru dipilih program pemerintah.
  Zona Bantuan tidak pernah dideklarasikan media. Bentuk formal penuhnya
  adalah Uji E (ketidakterlihatan media) dari rancangan MVP.

## Eksperimen tuning yang diukur lalu DITOLAK (4 Sep 2026)

Tiga kandidat penguat digali dari `panen/` dan `machine-learning/`, diukur di
`eksperimen_tuning.py` (hasil: `keluaran/eksperimen_tuning.json`), dan ditolak
dengan angka — bukan karena tidak dicoba:

1. **Komponen "dekat pelabuhan perikanan" (PIPP, 686 titik) di SUB_tangkap** —
   campuran: Cilacap membaik tajam (median #19,5 → #7) tetapi Sumbawa memburuk
   (AP 0,63 → 0,26; kampung nelayannya di pulau kecil, pelabuhan PIPP terdekat
   lintas laut) dan rerata AP 5 klaster turun 0,46 → 0,44. Menala bobotnya agar
   menang di semua klaster = overfitting pada 5 titik data. Ditolak; data
   pelabuhan tetap tersedia untuk Jalur Ekonomi.
2. **Spatial smoothing sub-skor (rerata 5 tetangga geografis, alfa 0,3)** —
   kunci internal 247 sel×kab: AP 0,5114 → 0,5135, menang hanya 117/247.
   Nihil. Ditolak.
3. **Sel LEMAH v5 (AP 0,25–0,40) sebagai pengganti fallback heuristik** —
   kelima sel LEMAH berada di provinsi×subsektor yang SUDAH punya sel LAYAK;
   tidak satu pun menutup lubang fallback. Ditolak tanpa uji lanjut.

Temuan sampingan yang bernilai di luar SP:
- **`kampung_budidaya_kkp_2023.csv` — 52 kampung level desa di 5 provinsi**
  (kolom Desa+Kecamatan+Komoditas). Diuji sebagai kunci pSUB_ikan: lemah
  (median peringkat ratusan) — dan itu temuan, bukan kegagalan: kampung
  budidaya adalah program PENGEMBANGAN (penempatan kebijakan), bukan sentra
  eksisting ST2023, jadi tidak sah sebagai ground truth potensi. Layak jadi
  lapisan fakta program di Kartu Ekonomi Desa.
- `cold_storage_titik_desa.csv` (312 unit eksisting ber-iddesa, kapasitas,
  status) dan `jadesta_detail.csv` (486 desa wisata + atraksi/paket/homestay)
  — kandidat lapisan fakta Kartu, bukan skor.
- `ruta_dingin_desa.csv` diturunkan dari kolom `kom_prov_*` (keluarga kunci
  internal) — memakainya sebagai fitur SP membocorkan kunci; tetap milik
  Jalur Ekonomi.

## Batasan yang dinyatakan

- Min-maks per kabupaten sensitif terhadap keluar-masuknya satu desa ekstrem
  (sifat metode; log1p meredam).
- SK aditif = kompensatori penuh; bobot adalah trade-off, bukan "tingkat
  kepentingan". Uji skema bobot adalah mitigasinya.
- Reweighting komponen hilang bisa bias bila kekosongan berkorelasi dengan
  kinerja (liputan OSM tipis di desa terpencil) — kelengkapan per wilayah
  dilaporkan supaya bisa digugat.
- Sel LABEL-TIPIS/LEMAH/TANPA-SINYAL v5 tidak dipakai; subsektor tanpa sel
  LAYAK jatuh ke heuristik yang mutunya lebih rendah (terlihat di
  `sumber_dominan`).
